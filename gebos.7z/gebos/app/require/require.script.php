<script src="assets/js/library/jquery-2.2.1.min.js"></script>
<script src="assets/js/library/bootstrap.min.js"></script>


<script src="assets/js/library/jquery.number.min.js"></script>
<script src="assets/js/library/jquery.dataTables.min.js"></script>
<script src="assets/js/library/dataTables.bootstrap.min.js"></script>



<script src="assets/js/library/moment.js"></script>

<script src="assets/js/library/iscroll.min.js"></script>
<script src="assets/js/library/drawer.min.js"></script>

<script src="assets/js/library/ejs_production.js"></script>



<script src="assets/js/module/module.app.js"></script>


<script>

var App = App || {};
    EJS.config({cache:false});

    $(document).on('ready',function(){
        $('.drawer').drawer();
    });
</script>
