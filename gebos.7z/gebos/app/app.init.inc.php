<?php
    require_once 'core/core.connection.inc.php';
    require_once 'core/core.app.inc.php';
    require_once 'core/core.controller.inc.php';
    require_once 'core/core.init.inc.php';
