<?php
/*
 * Create an empty array to store constants
 */
$DB_CONN = array();
/*
 * The database host URL
 */
$DB_CONN['DB_HOST'] = 'localhost';
/*
 * The database username
 */
$DB_CONN['DB_USER'] = 'admin';
/*
 * The database password
 */
$DB_CONN['DB_PASS'] = 'admin';
/*
 * The name of the database to work with
 */
$DB_CONN['DB_NAME'] = 'gebos';
?>
