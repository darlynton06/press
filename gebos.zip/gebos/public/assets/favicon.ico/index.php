<?php
    header('Location: public');
