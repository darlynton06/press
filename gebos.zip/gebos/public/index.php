<?php
    require_once '../app/app.init.inc.php';

    $app = new App;
